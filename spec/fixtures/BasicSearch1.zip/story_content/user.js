function ExecuteScript(strId) {
  switch (strId) {
    case "5oELDbs8O5G":
      Script1();
      break;
    case "5coaKzwBYFm":
      Script2();
      break;
  }
}

function Script1() {
  getDLCTransition('lesson');
}

function Script2() {
  window.parent.sendLessonCompletedEvent();
}
