function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6GfWrvNnrwd":
        Script1();
        break;
  }
}

function Script1()
{
  getDLCTransition('lesson');
}

